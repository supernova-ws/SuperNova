# Ion.Sound Update History

### Version 3.0.8. March 21, 2017
* Implemented request #52 - option to enable browser caching by Gorlum https://github.com/supernova-ws

### Version 3.0.7. March 06, 2016
* Fixed bug #71

### Version 3.0.6. August 04, 2015
* Fixed bug #49
* Attempt to fix #35

### Version 3.0.5. July 27, 2015
* Fixed bug #44

### Version 3.0.4. June 04, 2015
* Version jump to fix nmp
* Fixed bug #42

### Version 3.0.1. May 29, 2015
* Master volume added. Issues: #28, #38
* Fixed bugs #30, #31

### Version 3.0.0. February 10, 2015
* New Web Audio API core
* HTML5 fallback remastered
* Audio sprites support
* Advanced preloading controls
* Normal callbacks support
* Removed jQuery dependency

### Version 2.1.3. October 29, 2014
* Fixed some minor bugs in Firefox and MS IE

### Version 2.1.2. October 26, 2014
* Minor fix for iOS 8.x

### Version 2.1.1. October 25, 2014
* Minor fix

### Version 2.1.0. October 25, 2014
* AAC files support
* Minor bug fixes
* Callback "onEnded"
* SPM support

### Version 2.0.2. August 08, 2014
* New pause method
* Bower support

### Version 2.0.1. August 01, 2014
* 2 versions of plugin, jQuery and Vanilla JS

### Version 2.0.0. June 31, 2014
* New API
* Sound loop option

### Version 1.3.0. November 30, 2013
* Method "stop"
* Method "kill"
* Volume control added to "play" method

### Version 1.2.0. October 13, 2013
* Individual volume for any sound
* Improved test environment

### Version 1.1.0. September 21, 2013
* Plugin moved to jQuery namespace
* New method
* 10 new free sounds

### Version 1.0.1. September 08, 2013
* Bug fix in iOS

### Version 1.0.1. September 08, 2013
* Little enhancement

### Version 1.0.0. September 07, 2013
* Plugin release
